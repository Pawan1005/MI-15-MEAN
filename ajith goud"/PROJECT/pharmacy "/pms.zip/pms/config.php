<?php

// Database Details

define( "DB_HOST", "localhost" );
define( "DB_USER", "root" );
define( "DB_PASSWORD", "" );
define( "DB_NAME", "sourcecodester_pmsdb" );
